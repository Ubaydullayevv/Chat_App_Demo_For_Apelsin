package com.example.chat_app_apelsin.controller;

import com.example.chat_app_apelsin.dto.ChatDto;
import com.example.chat_app_apelsin.dto.UserDto2;
import com.example.chat_app_apelsin.payload.ApiResponse;
import com.example.chat_app_apelsin.service.ChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/chats/")
public class ChatController {
    @Autowired
    ChatService chatService;

    @PostMapping("add")
    public HttpEntity<?> createChat(@RequestBody ChatDto chatDto) {
        ApiResponse apiResponse = new ApiResponse();
        try {
            apiResponse = chatService.createChat(chatDto);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            apiResponse.setMessage(e.getMessage());
            return ResponseEntity.ok(apiResponse.getMessage());
        }
        if (!apiResponse.isSuccess()) {
            return ResponseEntity.ok(apiResponse.getMessage());
        }
        return ResponseEntity.ok(apiResponse.getData());

    }

    @GetMapping("get")
    public HttpEntity<?> getChat(@RequestBody UserDto2 user) {
        ApiResponse apiResponse = chatService.getChatByUserId(user.getUser());
        return ResponseEntity.ok(apiResponse.getData());
    }

}
