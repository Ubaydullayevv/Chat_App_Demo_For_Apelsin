package com.example.chat_app_apelsin.service;

import com.example.chat_app_apelsin.dto.MessageDto;
import com.example.chat_app_apelsin.entity.Chat;
import com.example.chat_app_apelsin.entity.Message;
import com.example.chat_app_apelsin.entity.User;
import com.example.chat_app_apelsin.entity.enums.MessageType;
import com.example.chat_app_apelsin.payload.ApiResponse;
import com.example.chat_app_apelsin.repo.ChatRepository;
import com.example.chat_app_apelsin.repo.MessageRepository;
import com.example.chat_app_apelsin.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageService {

    @Autowired
    ChatRepository chatRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    UserService userService;
    @Autowired
    MessageRepository messageRepository;

    public ApiResponse sendMessage(MessageDto messageDto) throws Exception {

        User user = userRepository.findById(messageDto.getAuthor()).orElseThrow(() -> new Exception("User not Found"));
        User author = userRepository.findById(messageDto.getAuthor(),messageDto.getChat()).orElseThrow(() -> new Exception("You dont have a permission for write this chat"));
        Chat chat = chatRepository.findById(messageDto.getChat()).orElseThrow(() -> new Exception("Chat not found"));
        if (messageDto.getType().equalsIgnoreCase("text")) {
            Message save = messageRepository.save(new Message(chat, author, MessageType.TEXT, messageDto.getContent()));
            ApiResponse apiResponse = new ApiResponse();
            if (save.getId() == null) {
                apiResponse.setMessage("Could not add");
                return apiResponse;
            }
            apiResponse.setSuccess(true);
            apiResponse.setData(save.getId());
            return apiResponse;
        }
       /* String encode = writePic(messageDto.getContent());
        Message message = messageRepository.save(new Message(chat, author, MessageType.IMAGE, encode));
        String directory = getDirectory(message);*/


        return null;
    }

    public ApiResponse getMessageChatById(Integer chat)  {
        List<Message> chats = messageRepository.findByChatIdOrderByCreated_atAsc(chat);
        ApiResponse apiResponse = new ApiResponse();
        if (chats.isEmpty()) {
            return new ApiResponse("No messages");
        }
        apiResponse.setData(chats);
        return apiResponse;
    }
   /* public String writePic(String message) throws Exception {
        String stringEncodedImage="";
        try (InputStream stream = new FileInputStream(message)) {
            byte[] imageBytes = stream.readAllBytes();
             stringEncodedImage = Base64.getEncoder().encodeToString(imageBytes);
        *//*    String copiedFileName = "src/main/resources/files/copied.jpg";
            File copiedFile = new File(copiedFileName);
            if (!copiedFile.exists()) {
                boolean created = copiedFile.createNewFile();
                if (created) {
                    OutputStream outputStream = new FileOutputStream(copiedFile);
                    outputStream.write(Base64.getDecoder().decode(stringEncodedImage));
                }
            }
*//*
        } catch (IOException e) {
            e.printStackTrace();
        }
return stringEncodedImage;
    }
    public String getDirectory(Message message){
       String path="src/main/resources/templates";
        String fileDownloadUri = "";
            LocalDateTime uploadTime = message.getCreated_at();
            int year = uploadTime.getYear();
            int month = uploadTime.getMonthValue();
            int day = uploadTime.getDayOfMonth();
            File file5 = new File(path + "\\uploads");
            if (!file5.exists()) {
                file5.mkdir();
            }
            File file1 = new File(file5 + "\\" + year);
            if (!file1.exists()) {
                file1.mkdir();
            }
            File file2 = new File(file1 + "\\" + month);
            if (!file2.exists()) {
                file2.mkdir();
            }
            File file3 = new File(file2 + "\\" + day);
            if (!file3.exists()) {
                file3.mkdir();
            }
            return file3.getAbsolutePath();
        }
    public String writeFile(String filePath,MessageDto message){

    String fileDownloadUri = "";

        String newPath = filePath + "\\" + message.getContent();
        File file=new File(newPath);

        fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(message.getContent())
                .toUriString();

        return fileDownloadUri;
}*/
}
