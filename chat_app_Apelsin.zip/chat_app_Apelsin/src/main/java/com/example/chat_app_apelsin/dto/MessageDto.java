package com.example.chat_app_apelsin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MessageDto {
    private Integer chat;
    private Integer author;
    private String type;
    private String content;
    private String ext;
}

