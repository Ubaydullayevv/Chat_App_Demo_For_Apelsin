package com.example.chat_app_apelsin.entity.enums;

public enum MessageType {
   IMAGE,
    TEXT
}
