package com.example.chat_app_apelsin.repo;

import com.example.chat_app_apelsin.entity.Chat;
import com.example.chat_app_apelsin.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ChatRepository extends JpaRepository<Chat,Integer> {
    @Query(nativeQuery = true,
            value = "select c.* from chats c" +
                    " join chats_users cu on c.id = cu.chats_id" +
                    " join users u on u.id = cu.users_id" +
                    " where u.id=:userId order by  c.created_at ASC ")
    List<Chat> findAllByUsersOrderByCreated_atDesc(Integer userId);
}
