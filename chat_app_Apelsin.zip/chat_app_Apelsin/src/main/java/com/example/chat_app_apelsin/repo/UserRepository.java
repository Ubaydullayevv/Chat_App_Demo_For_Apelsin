package com.example.chat_app_apelsin.repo;

import com.example.chat_app_apelsin.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    Boolean existsByUsername(String username);

    @Query(
            nativeQuery = true,
            value = "select u.*\n" +
                    "from users u\n" +
                    "         join chats_users cu on u.id = cu.users_id\n" +
                    "join chats c on c.id = cu.chats_id\n" +
                    "where u.id =:id and chats_id=:chatId")
    Optional<User> findById(Integer id,Integer chatId);
}
