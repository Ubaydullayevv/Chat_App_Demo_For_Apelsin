package com.example.chat_app_apelsin.dto;

import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ChatDto {
    private String name;
    private List<Integer> users;

}
