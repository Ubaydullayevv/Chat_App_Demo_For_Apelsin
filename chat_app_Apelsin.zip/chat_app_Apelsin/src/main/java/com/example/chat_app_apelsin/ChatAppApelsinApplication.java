package com.example.chat_app_apelsin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatAppApelsinApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChatAppApelsinApplication.class, args);
    }

}
