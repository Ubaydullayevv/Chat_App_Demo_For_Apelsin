package com.example.chat_app_apelsin.service;

import com.example.chat_app_apelsin.dto.ChatDto;
import com.example.chat_app_apelsin.entity.Chat;
import com.example.chat_app_apelsin.entity.User;
import com.example.chat_app_apelsin.payload.ApiResponse;
import com.example.chat_app_apelsin.repo.ChatRepository;
import com.example.chat_app_apelsin.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ChatService {
    @Autowired
    ChatRepository chatRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    UserService userService;

    public ApiResponse createChat(ChatDto chatDto) throws Exception {
        List<User> userList = new ArrayList<>();
        if (chatDto.getUsers().isEmpty()) {
            return new ApiResponse("Please enter users",false);
        }
        for (Integer user : chatDto.getUsers()) {
            userList.add(userRepository.findById(user).orElseThrow(() -> new Exception(user + "id is not found")));
        }
        Chat save = chatRepository.save(new Chat(chatDto.getName(), userList));
        ApiResponse apiResponse = new ApiResponse();
        if (save.getId() == null) {
            apiResponse.setMessage("Could not add");
            return apiResponse;
        }
        apiResponse.setSuccess(true);
        apiResponse.setData(save.getId());
        return apiResponse;
    }

    public ApiResponse getChatByUserId(Integer user) {
        List<Chat> allByUsersOrderByCreated_atDesc = chatRepository.findAllByUsersOrderByCreated_atDesc(user);
        if (allByUsersOrderByCreated_atDesc.isEmpty()) {
            return new ApiResponse("You dont have any chats yet",false);
        }
        return new ApiResponse(allByUsersOrderByCreated_atDesc);
    }
}
