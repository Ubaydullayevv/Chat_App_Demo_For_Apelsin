package com.example.chat_app_apelsin.payload;


import lombok.*;
import org.springframework.http.HttpEntity;

@AllArgsConstructor
@NoArgsConstructor
//@Data
@Getter
@Setter
@ToString
 public class ApiResponse  {
    private String message;

    private boolean isSuccess;

    private Object data;

    public ApiResponse(Object data) {
        this.data = data;
    }


    public ApiResponse(String message, boolean isSuccess) {
        this.message = message;
        this.isSuccess = isSuccess;
    }
}
