package com.example.chat_app_apelsin.controller;

import com.example.chat_app_apelsin.dto.ChatDto2;
import com.example.chat_app_apelsin.dto.MessageDto;
import com.example.chat_app_apelsin.payload.ApiResponse;
import com.example.chat_app_apelsin.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/messages/")
public class MessageController {
    @Autowired
    MessageService messageService;

    @PostMapping("add")
    public HttpEntity<?> sendMessage(@RequestBody MessageDto messageDto) throws Exception {

        ApiResponse apiResponse = new ApiResponse();
        try {
            apiResponse = messageService.sendMessage(messageDto);
        } catch (Exception e) {
            apiResponse.setMessage(e.getMessage());
            return ResponseEntity.ok(apiResponse.getMessage());
        }
        if (!apiResponse.isSuccess()) {
            return ResponseEntity.badRequest().body(apiResponse.getMessage()
            );
        }
        return ResponseEntity.ok(apiResponse.getData());
    }

    @GetMapping("get")
    public HttpEntity<?> getMessagesByChatId(@RequestBody ChatDto2 chat) {
        ApiResponse messageChatById = messageService.getMessageChatById(chat.getChat());

        if (!messageChatById.isSuccess()) {
            return ResponseEntity.badRequest().body(messageChatById.getMessage());
        }
        return ResponseEntity.ok(messageChatById.getData());
    }

}
