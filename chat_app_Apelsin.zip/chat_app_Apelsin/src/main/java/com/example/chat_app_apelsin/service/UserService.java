package com.example.chat_app_apelsin.service;

import com.example.chat_app_apelsin.entity.User;
import com.example.chat_app_apelsin.payload.ApiResponse;
import com.example.chat_app_apelsin.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;

    public ApiResponse addUser(String username) {
        ApiResponse apiResponse = new ApiResponse();
        if (username == null) {
            apiResponse.setMessage("Username could not be empty");
            return apiResponse;
        }
        Boolean aBoolean = userRepository.existsByUsername(username);
        if (aBoolean) {
            apiResponse.setMessage("Username already exist");
            return apiResponse;
        }
        User save = userRepository.save(new User(username));
        if (save.getId() == null) {
            apiResponse.setMessage("Could not add");
            return apiResponse;
        }
        apiResponse.setSuccess(true);
        apiResponse.setData(save.getId());
        return apiResponse;
    }
}
