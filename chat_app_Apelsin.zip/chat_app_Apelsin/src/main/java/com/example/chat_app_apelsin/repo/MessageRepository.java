package com.example.chat_app_apelsin.repo;

import com.example.chat_app_apelsin.entity.Message;
import com.example.chat_app_apelsin.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MessageRepository extends JpaRepository<Message, Integer> {
    @Query(
            nativeQuery = true,

            value = "select m.* from messages m where m.chat_id = ?1 order by m.created_at ASC "
    )
    List<Message> findByChatIdOrderByCreated_atAsc(Integer chatId);

}
