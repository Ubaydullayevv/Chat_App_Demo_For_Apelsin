package com.example.chat_app_apelsin.controller;

import com.example.chat_app_apelsin.dto.UserDto;
import com.example.chat_app_apelsin.payload.ApiResponse;
import com.example.chat_app_apelsin.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users/")
public class UserController {
    @Autowired
    UserService userService;

    @PostMapping("/add")
    public HttpEntity<?> addUser(@RequestBody UserDto userDto) {
        ApiResponse apiResponse = userService.addUser(userDto.getUsername());
        if (!apiResponse.isSuccess()) {
            return ResponseEntity.badRequest().body(apiResponse.getMessage()
            );
        }
        return ResponseEntity.ok(apiResponse.getData());
    }


}
