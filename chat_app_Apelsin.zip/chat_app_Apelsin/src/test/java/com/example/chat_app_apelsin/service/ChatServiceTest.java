package com.example.chat_app_apelsin.service;

import com.example.chat_app_apelsin.dto.ChatDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class ChatServiceTest {
  @Autowired
  ChatService chatService=new ChatService();
    @Test
    void createChat() throws Exception {
       assertEquals(5,chatService.createChat(new ChatDto("chat1adea",new ArrayList<>(Arrays.asList(2,3)))));
    }

    @Test
    void getChatByUserId() {
    }
}