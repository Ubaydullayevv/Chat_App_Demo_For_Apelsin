package com.example.chat_app_apelsin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatAppApelsinApplicationTests {

    @Test
    void contextLoads() {
    }

}
