Rasm upload qilishda berilgan  linkda muammo bor.
Task tuzuvchi boglanish imkoni bolgani sababli,
bu funksiya qoshilmadi.
User qoshish:http://localhost:8080/users/add
Chat qo'shish:http://localhost:8080/chats/add
xabar yuborish:http://localhost:8080/messages/add
xabarlarni korish: http://localhost:8080/messages/get
chatlarni korish: http://localhost:8080/chats/get

(Dokumentatsiyada korsatilhan chat yaratish uslubi best case emas 
chunki user1 user2ga message yuborganda alohida chat user2 user1ga message yuborganda alohida chat ochiladi
Optimal usuli boshqacharoq boladi
)
